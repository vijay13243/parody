package com.capg.Hotolpojo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class Loginpojo {
	@FindBy(name="userName")
	WebElement Username;
    @FindBy(name="userPwd")
    WebElement password;
  @FindBy(className="btn")
  WebElement loginbtn;
	public WebElement getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		//System.out.println("kjfed");
		Username.sendKeys(username);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getLoginbtn() {
		return loginbtn;
	}

	public void setLoginbtn() {
		this.loginbtn.click();
	}
	
	

}
