package com.capg.Hotolpojo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class hotelbookpojo {
	@FindBy(id="txtFirstName")
	WebElement FirstName;
	@FindBy(id="txtLastName")
	WebElement LastName;
	@FindBy(name="Email")
WebElement Email;
	public WebElement getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName.sendKeys(lastName);
	}
	
	

}
