package com.capg.Hotelsepdef;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.capg.Hotolpojo.Loginpojo;
import com.capg.Hotolpojo.hotelbookpojo;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelSetdefination {
	private static WebDriver driver;
	static Loginpojo login=new Loginpojo();
	static hotelbookpojo sub=new hotelbookpojo(); 
	@BeforeClass
	@Given("^User is on 'login' Page$")
	public static void user_is_on_login_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","C:\\celenium\\conferencepayment\\Drivers\\chromedriver (1).exe");
		driver= new ChromeDriver();
		driver.get("C:\\celenium\\Hotel\\Htmlfiles\\login.html");
		PageFactory.initElements(driver,login);
		
	}
	@Test
	@When("^user enters invalid UserName$")
	public void user_enters_invalid_UserName() throws Throwable {
		//System.out.println("dshggdj");
		login.setUsername("Yogini");
	    login.setPassword("Yogini");
	    login.setLoginbtn();
	    driver.get("C:\\celenium\\Hotel\\Htmlfiles\\hotelbooking.html");
		PageFactory.initElements(driver,sub);
		sub.setFirstName("pavan");
		sub.setLastName("cheruvu");
	}

	@Then("^display 'Please Enter UserName'$")
	public void display_Please_Enter_UserName() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user enters invalid password$")
	public void user_enters_invalid_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display 'Please Enter Password'$")
	public void display_Please_Enter_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid details$")
	public void user_enters_invalid_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display 'Invalid Login Please try again'$")
	public void display_Invalid_Login_Please_try_again() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display 'HotelBooking' Page$")
	public void display_HotelBooking_Page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^user is on 'hotelBooking' page$")
	public void user_is_on_hotelBooking_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please fill the first Name'$")
	public void displays_Please_fill_the_first_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid last name$")
	public void user_enters_invalid_last_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please fill the Last Name'$")
	public void displays_Please_fill_the_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display 'Please fill Mobile No\\.'$")
	public void display_Please_fill_Mobile_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters wrong mobile number$")
	public void user_enters_wrong_mobile_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display 'Please enter valid Mobile Number'$")
	public void display_Please_enter_valid_Mobile_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid Number of People staying$")
	public void user_enters_invalid_Number_of_People_staying() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display 'Number of people staying'$")
	public void display_Number_of_people_staying() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user does not enter address$")
	public void user_does_not_enter_address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display 'Please Enter Address'$")
	public void display_Please_Enter_Address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid City$")
	public void user_enters_invalid_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display 'Please fill City'$")
	public void display_Please_fill_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid State$")
	public void user_enters_invalid_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^display 'Please fill the State'$")
	public void display_Please_fill_the_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please fill the CardHolder Name'$")
	public void displays_Please_fill_the_CardHolder_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid Debit Card Number$")
	public void user_enters_invalid_Debit_Card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please fill Debit Card Number'$")
	public void displays_Please_fill_Debit_Card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user does not enter CVV value$")
	public void user_does_not_enter_CVV_value() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please fill CVV number'$")
	public void displays_Please_fill_CVV_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid expiration month$")
	public void user_enters_invalid_expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please fill expiration month'$")
	public void displays_Please_fill_expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters invalid expiration year$")
	public void user_enters_invalid_expiration_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Please fill expiration year'$")
	public void displays_Please_fill_expiration_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user enters valid  payment details$")
	public void user_enters_valid_payment_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^displays 'Booking Completed!!!'$")
	public void displays_Booking_Completed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}



}
