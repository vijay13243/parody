package com.capg.bdd.conferencepayment;

import org.junit.*;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.PendingException;
import cucumber.api.java.en.*;


public class conference {
	private static WebDriver driver;
	static conferencepojo bean = new conferencepojo();
	 paymentpojo pojo= new paymentpojo();
	
	@Before
	public void init(){
		System.setProperty("webdriver.chrome.driver","C:\\celenium\\conferencepayment\\Drivers\\chromedriver (1).exe");
		driver= new ChromeDriver();
	}
	@Test
	@Given("^User is on Conference room booking page$")
	public void user_is_on_Conference_room_booking_page() throws Throwable {
		
		driver.get("C:\\celenium\\conferencepayment\\html\\ConferenceRegistartion (1).html");
		bean= new  conferencepojo();
		PageFactory.initElements(driver,bean);
		bean.clickNextPageLink();
		Thread.sleep(2000);
		please_fill_the_First_Name_message_should_display();
		user_select_Next_link_without_entering_LastName();
		please_fill_the_Last_Name_message_should_display();
		user_select_Next_link_without_entering_Email() ;
		 please_fill_the_Email_message_should_display();
		 user_select_Next_link_without_entering_Contact_No();
		 please_fill_the_Contact_No_message_should_display();
		 user_select_Next_link_without_selecting_Number_of_people_attending();
		 please_fill_the_Number_of_people_attending_message_should_display();
		 user_select_Next_link_without_entereing_Building_Name_Room_No();
		 please_fill_the_Building_Room_No_message_should_display();
		 user_select_Next_link_without_entereing_Area_Name();
		 please_fill_the_Area_name_message_should_display();
		 user_select_Next_link_without_selecting_City();
		 please_select_city_message_should_display();
		 user_select_Next_link_without_selecting_State() ;
		 please_select_state_message_should_display();
		 user_select_Next_link_without_selecting_MemberShip_Status();
		 please_Select_MemeberShip_status_message_should_display();
		 user_select_Next_link_after_entering_Valid_set_of_information();
		 personal_details_are_validated_message_should_display();
		 user_is_on_Payment_details_page();
		 select_Next_link_without_entering_cardholdername();
		 
		 
	
	}


	@When("^select 'Next' link without entering 'FirstName'$")
	public void select_Next_link_without_entering_FirstName() throws Throwable {
	String actualMessage=driver.switchTo().alert().getText();
	String expectedMessage ="Please fill the First Name";
	Assert.assertEquals(expectedMessage, actualMessage);
	}

	@Then("^'Please fill the First Name' message should display$")
	public void please_fill_the_First_Name_message_should_display() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setFirstname("pavan");
		
	   
	}

	@When("^User select 'Next' link without entering 'LastName'$")
	public void user_select_Next_link_without_entering_LastName() throws Throwable {
		
		bean.clickNextPageLink();
	}

	@Then("^'Please fill the Last Name' message should display$")
	public void please_fill_the_Last_Name_message_should_display() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setLastname("cheruvu");
	}

	@When("^User select 'Next' link without entering 'Email'$")
	public void user_select_Next_link_without_entering_Email() throws Throwable {
		bean.clickNextPageLink();
	}

	@Then("^'Please fill the Email message should display$")
	public void please_fill_the_Email_message_should_display() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setEmail("pavaneee111@gmail.com");
	}

	@When("^User select 'Next' link after entering invalid 'Email' address$")
	public void user_select_Next_link_after_entering_invalid_Email_address() throws Throwable {
	  
	    throw new PendingException();
	}

	@Then("^'Please enter valid Email Id\\. message should display$")
	public void please_enter_valid_Email_Id_message_should_display() throws Throwable {
		
	}

	@When("^User select 'Next' link without entering 'Contact No'$")
	public void user_select_Next_link_without_entering_Contact_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		bean.clickNextPageLink();
		
	}

	@Then("^'Please fill the Contact No message should display$")
	public void please_fill_the_Contact_No_message_should_display() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setContactNo("9676834844");
	}

	@When("^User select 'Next' link after entering invalid 'Contact No'$")
	public void user_select_Next_link_after_entering_invalid_Contact_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Please enter valid Contact no message should display$")
	public void please_enter_valid_Contact_no_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User select 'Next' link without selecting  'Number of people attending'$")
	public void user_select_Next_link_without_selecting_Number_of_people_attending() throws Throwable {
		bean.clickNextPageLink();
	}

	@Then("^'Please fill the Number of people attending' message should display$")
	public void please_fill_the_Number_of_people_attending_message_should_display() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setPersonCount("4");
	}

	@When("^User select 'Next' link without entereing  'Building Name & Room No'$")
	public void user_select_Next_link_without_entereing_Building_Name_Room_No() throws Throwable {
		bean.clickNextPageLink();
	}

	@Then("^'Please fill the Building & Room No' message should display$")
	public void please_fill_the_Building_Room_No_message_should_display() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setRooms("Amaravathi");
	}

	@When("^User select 'Next' link without entereing  'Area Name'$")
	public void user_select_Next_link_without_entereing_Area_Name() throws Throwable {
		bean.clickNextPageLink();
	}

	@Then("^'Please fill the Area name' message should display$")
	public void please_fill_the_Area_name_message_should_display() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setArea("Nungambakam");
	}

	@When("^User select 'Next' link without selecting  'City'$")
	public void user_select_Next_link_without_selecting_City() throws Throwable {
		bean.clickNextPageLink();
	}

	@Then("^'Please select city' message should display$")
	public void please_select_city_message_should_display() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setCity("Pune");
	}

	@When("^User select 'Next' link without selecting  'State'$")
	public void user_select_Next_link_without_selecting_State() throws Throwable {
		bean.clickNextPageLink();
	}

	@Then("^'Please select state' message should display$")
	public void please_select_state_message_should_display() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setState("Maharashtra");
	}

	@When("^User select 'Next' link without selecting  'MemberShip Status '$")
	public void user_select_Next_link_without_selecting_MemberShip_Status() throws Throwable {
		bean.clickNextPageLink();
	}

	@Then("^'Please Select MemeberShip status' message should display$")
	public void please_Select_MemeberShip_status_message_should_display() throws Throwable {
		driver.switchTo().alert().dismiss();
		bean.setMemberStatus("non-member");
	}

	@When("^User select 'Next' link after entering 'Valid set of information'$")
	public void user_select_Next_link_after_entering_Valid_set_of_information() throws Throwable {
		bean.clickNextPageLink();
		personal_details_are_validated_message_should_display();
	}

	@Then("^'Personal details are validated message should display$")
	public void personal_details_are_validated_message_should_display() throws Throwable {
		driver.switchTo().alert().dismiss();
		driver.get("C:\\celenium\\conferencepayment\\html\\PaymentDetails.html");
		PageFactory.initElements(driver,pojo);
		user_is_on_Payment_details_page();
		
	}

	@Given("^User is on Payment details page$")
	public void user_is_on_Payment_details_page() throws Throwable {
		System.out.println("cardholder");
		pojo.setMakepayment();
		driver.switchTo().alert().dismiss();
		pojo.setCardholdername("vgerhgtedhr");
		pojo.setMakepayment();
		driver.switchTo().alert().dismiss();
		pojo.setDebitcard("gfuyfge");
		pojo.setMakepayment();
		driver.switchTo().alert().dismiss();
		pojo.setCvv("567");
		pojo.setMakepayment();
		driver.switchTo().alert().dismiss();
		pojo.setMonth("123");
		pojo.setMakepayment();
		String actual=driver.switchTo().alert().getText();
		String Expected="Please fill expiration month";
		//Assert.assertEquals(actual,Expected);
		driver.switchTo().alert().dismiss();
		pojo.setYear("1234");
		pojo.setMakepayment();
		verify_the_title_personal_Details_of_the_page();
	    //System.out.println("hydgf");
	}

	@Then("^'verify the title 'personal Details'of the page$")
	public void verify_the_title_personal_Details_of_the_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//driver.switchTo().alert().dismiss();
		//select_Next_link_without_entering_cardholdername();
		pojo.setCardholdername("ijhowhvow");
		
		
	}

	@When("^select 'Next' link without entering 'cardholdername'$")
	public void select_Next_link_without_entering_cardholdername() throws Throwable {
		//System.out.println("yes");
		//driver.switchTo().alert().dismiss();
		System.out.println("yes");
		please_fill_the_cardholder_Name_message_should_display();
		
	}

	@Then("^'Please fill the cardholder Name' message should display$")
	public void please_fill_the_cardholder_Name_message_should_display() throws Throwable {
	//driver.switchTo().alert().dismiss();
	//System.out.println("yes");
		driver.findElement(By.id("txtFN")).sendKeys("pavan");
	}

	@When("^User select 'Next' link without entering 'debit card number'$")
	public void user_select_Next_link_without_entering_debit_card_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Please fill the debit card' message should display$")
	public void please_fill_the_debit_card_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User select 'Next' link without entering 'CVV'$")
	public void user_select_Next_link_without_entering_CVV() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Please fill the cvv' message should display$")
	public void please_fill_the_cvv_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User select 'Next' link without entering 'card expiration month'$")
	public void user_select_Next_link_without_entering_card_expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Please fill the card card expiration month' message should display$")
	public void please_fill_the_card_card_expiration_month_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^select 'Next' link without entering 'card expiration year'$")
	public void select_Next_link_without_entering_card_expiration_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Please fill the card expiration year' message should display$")
	public void please_fill_the_card_expiration_year_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^user selects make payment button$")
	public void user_selects_make_payment_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Conference room booking succesfully done' message should display$")
	public void conference_room_booking_succesfully_done_message_should_display() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}



}
