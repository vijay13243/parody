package com.capg.bdd.conferencepayment;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class conferencepojo {
	WebDriver driver;
	@FindBy(name="txtFN")
	WebElement firstname;
	@FindBy(name="txtLN")
	WebElement lastname;
	@FindBy(how=How.NAME, using="Email")
	WebElement email;
	@FindBy(name="Phone")
	WebElement contactNo;
	@FindBy(how=How.NAME, using="size")
WebElement personCount;
	@FindBy(name="Address")
	WebElement rooms;
	@FindBy(name = "Address2")
	WebElement area;
	@FindBy(how=How.NAME, using="city")
	WebElement city;
	@FindBy(how=How.NAME, using="state")
	WebElement state;
	@FindBy(how=How.NAME , name="memberStatus")
	private List<WebElement> memberStatus;
	@FindBy(how=How.LINK_TEXT,linkText="Next")
	private WebElement nextLink;
	
	public void clickNextPageLink() {
		nextLink.click();
	}
	public WebElement getNextLink() {
		return nextLink;
	}
	public void setNextLink() {
		this.nextLink.click();
	}
	public String getFirstname() {
		return firstname.getAttribute("value");
	}
	public void setFirstname(String firstname) {
		this.firstname.sendKeys(firstname);
	}
	public String getLastname() {
		return lastname.getAttribute("value");

	}
	public void setLastname(String lastname) {
		this.lastname.sendKeys(lastname);;
	}
	public String getEmail() {
		return email.getAttribute("value");
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}
	public String getContactNo() {
		return (contactNo.getAttribute("value"));
	}
	public void setContactNo(String contactNo) {
		this.contactNo.sendKeys(contactNo);
	}
	public int getPersonCount(){
		return  Integer.parseInt(new Select(personCount).
				getFirstSelectedOption().getText());
	}
	public void setPersonCount(String personCount) {
		new Select(this.personCount).
		 selectByVisibleText(personCount);
	}
	public String getRooms() {
		return rooms.getAttribute("value");
	}
	public void setRooms(String rooms) {
		this.rooms.sendKeys(rooms);
	}
	public String getArea() {
		return area.getAttribute("value");
	}
	public void setArea(String area) {
		this.area.sendKeys(area);
	}
	public String getCity() {
		return new Select(this.city).getFirstSelectedOption().getText();
	}
	public void setCity(String city) {
		new Select(this.city).selectByVisibleText(city);
	}
	public String getState() {
		return new Select(this.state).getFirstSelectedOption().getText();
	}
	public void setState(String state) {
		new Select(this.state).selectByVisibleText(state);
	}
	public String getMemberStatus() {
		for (WebElement webElement : memberStatus) 
			if(webElement.isSelected())
				return webElement.getAttribute("value");
			return null;
	}
	public void setMemberStatus(String memberStatus) {
		if(memberStatus.equals("member"))
			this.memberStatus.get(0).click();
		else if(memberStatus.equals("non-member"))
			this.memberStatus.get(1).click();
	}
	
	
	
	
}

