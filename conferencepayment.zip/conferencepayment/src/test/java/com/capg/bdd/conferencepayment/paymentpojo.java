package com.capg.bdd.conferencepayment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class paymentpojo {
	WebDriver driver;
	@FindBy(id="txtCardholderName")
	WebElement cardholdername;
	@FindBy(name="debit")
	WebElement debitcard;
	@FindBy(name="cvv")
	WebElement cvv;
	@FindBy(name="month")
	WebElement month;
	@FindBy(name="year")
	WebElement year;
	@FindBy(id="btnPayment")
	WebElement makepayment;
	
	public paymentpojo(){
		
	}
	
	
	public WebElement getCardholdername() {
		return cardholdername;
	}
	public void setCardholdername(String choldername) {
		this.cardholdername.sendKeys(choldername);
	}
	public WebElement getDebitcard() {
		return debitcard;
	}
	public void setDebitcard(String debitcard) {
		this.debitcard.sendKeys(debitcard);
	}
	public WebElement getCvv() {
		return cvv;
	}
	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);;
	}
	public WebElement getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month.sendKeys(month);
	}
	public WebElement getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year.sendKeys(year);
	}
	public WebElement getMakepayment() {
		return makepayment;
	}
	public void setMakepayment() {
		this.makepayment.click();
	}
	
}
