package com.capgemini.Customer;

public class Loan {
	private long LoanID;
	private double LoanAmount;
	private long CustId;
	private int Duration;
	public Loan(long loanID, double loanAmount, long custId, int duration) {
		super();
		LoanID = loanID;
		LoanAmount = loanAmount;
		CustId = custId;
		Duration = duration;
	}
	public long getLoanID() {
		return LoanID;
	}
	public void setLoanID(long loanID) {
		LoanID = loanID;
	}
	public double getLoanAmount() {
		return LoanAmount;
	}
	public void setLoanAmount(double loanAmount) {
		LoanAmount = loanAmount;
	}
	public long getCustId() {
		return CustId;
	}
	public void setCustId(long custId) {
		CustId = custId;
	}
	public int getDuration() {
		return Duration;
	}
	public void setDuration(int duration) {
		Duration = duration;
	}
	@Override
	public String toString() {
		return "Loan [LoanID=" + LoanID + ", LoanAmount=" + LoanAmount + ", CustId=" + CustId + ", Duration=" + Duration
				+ "]";
	}
	
	

}
