package com.capgemini.Customer;

import java.util.HashMap;



public class LoanImpl {
HashMap<Long,Customer> customerdetails = new HashMap<>();
	
	HashMap<Long,Loan> loandetails = new HashMap<>();
	
	


	
	public long insertCust(Customer cust) {
		customerdetails.put(cust.getCustId(),cust);
		// TODO Auto-generated method stub
		return cust.getCustId();
	}

	
	public long applyLoan(Loan ln) {
		// TODO Auto-generated method stub
		loandetails.put(ln.getLoanID(), ln);
		return 0;
	}
	public Double getEmi(Loan ln) {
		// TODO Auto-generated method stub
		Double d1=(ln.getLoanAmount()*0.95*(1+0.95)*ln.getDuration())/(((1+0.95)*ln.getDuration())-1);
		
		return d1;
	}

}



