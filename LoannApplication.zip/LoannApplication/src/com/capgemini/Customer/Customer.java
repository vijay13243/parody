package com.capgemini.Customer;

public class Customer {
	private long CustId;
	private String CustName;
	private String Address;
	private long Mobile;
	private String Email;
	private String LoanTypes;
	private double Salary;
	private int Aadharnumber;
	private int Pannumber;
	public Customer(long custId, String custName, String address, long mobile, String email, String loanTypes,
			double salary, int aadharnumber, int pannumber) {
		super();
		CustId = custId;
		CustName = custName;
		Address = address;
		Mobile = mobile;
		Email = email;
		LoanTypes = loanTypes;
		Salary = salary;
		Aadharnumber = aadharnumber;
		Pannumber = pannumber;
	}
	public long getCustId() {
		return CustId;
	}
	public void setCustId(long custId) {
		CustId = custId;
	}
	public String getCustName() {
		return CustName;
	}
	public void setCustName(String custName) {
		CustName = custName;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public long getMobile() {
		return Mobile;
	}
	public void setMobile(long mobile) {
		Mobile = mobile;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getLoanTypes() {
		return LoanTypes;
	}
	public void setLoanTypes(String loanTypes) {
		LoanTypes = loanTypes;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	public int getAadharnumber() {
		return Aadharnumber;
	}
	public void setAadharnumber(int aadharnumber) {
		Aadharnumber = aadharnumber;
	}
	public int getPannumber() {
		return Pannumber;
	}
	public void setPannumber(int pannumber) {
		Pannumber = pannumber;
	}
	@Override
	public String toString() {
		return "Customer [CustId=" + CustId + ", CustName=" + CustName + ", Address=" + Address + ", Mobile=" + Mobile
				+ ", Email=" + Email + ", LoanTypes=" + LoanTypes + ", Salary=" + Salary + ", Aadharnumber="
				+ Aadharnumber + ", Pannumber=" + Pannumber + "]";
	}
	
}