package com.capg.loan.entities;

public class Customer {
	
		private long custId;
		private String custName;
		private String address;
		private long mobile;
		private String email;
		private String loanTypes;
		private double salary;
		public Customer() {
			
		}
		public Customer(long custId, String custName, String address, long mobile, String email, String loanTypes,
				double salary) {
			this.custId = custId;
			this.custName = custName;
			this.address = address;
			this.mobile = mobile;
			this.email = email;
			this.loanTypes = loanTypes;
			this.salary = salary;
		}
		public long getCustId() {
			return custId;
		}
		public void setCustId(long custId) {
			this.custId = custId;
		}
		public String getCustName() {
			return custName;
		}
		public void setCustName(String custName) {
			this.custName = custName;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public long getMobile() {
			return mobile;
		}
		public void setMobile(long mobile) {
			this.mobile = mobile;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getLoanTypes() {
			return loanTypes;
		}
		public void setLoanTypes(String loanTypes) {
			this.loanTypes = loanTypes;
		}
		public double getSalary() {
			return salary;
		}
		public void setSalary(double salary) {
			this.salary = salary;
		}
		@Override
		public String toString() {
			return "Customer [custId=" + custId + ", custName=" + custName + ", address=" + address + ", mobile="
					+ mobile + ", email=" + email + ", loanTypes=" + loanTypes + ", salary=" + salary + "]";
		}
		

		


}
