package com.capg.loan.dao;

import com.capg.loan.entities.Customer;
import com.capg.loan.entities.Loan;

public interface LoanInterface {
	long insertCust(Customer cust);
	long applyLoan(Loan ln);
}
