package com.capg.loan.dao;

import java.util.*;

import com.capg.loan.entities.Customer;
import com.capg.loan.entities.Loan;

public class Loanimpl implements LoanInterface{
	HashMap<Long,Customer> customerdetails = new HashMap<>();
	
	HashMap<Long,Loan> loandetails = new HashMap<>();
	
	

	public Loanimpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public long insertCust(Customer cust) {
		customerdetails.put(cust.getCustId(),cust);
		// TODO Auto-generated method stub
		return cust.getCustId();
	}

	@Override
	public long applyLoan(Loan ln) {
		// TODO Auto-generated method stub
		loandetails.put(ln.getLoanID(), ln);
		return 0;
	}
	public Double getEmi(Loan ln) {
		// TODO Auto-generated method stub
		Double d1=(ln.getLoanAmount()*0.95*(1+0.95)*ln.getDuration())/(((1+0.95)*ln.getDuration())-1);
		
		return d1;
	}

}
